import transporter from '../config/nodemailer.js'
import crypto from 'crypto'

let otpStore = {} // Temporary in-memory store

export const sendOtp = async (req, res) => {
  const { email } = req.body
  if (!email) return res.status(400).json({ message: 'Email required' })

  const otp = Math.floor(100000 + Math.random() * 900000).toString()
  const expiresAt = Date.now() + 5 * 60 * 1000 // expires in 5 minutes

  otpStore[email] = { otp, expiresAt }

  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: email,
    subject: 'Your OTP Code',
    text: `Your OTP code is: ${otp} (valid for 5 minutes)`,
  }

  try {
    await transporter.sendMail(mailOptions)
    res.status(200).json({ success: true, message: 'OTP sent' })
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to send OTP', error: error.message })
  }
}

export const verifyOtp = (req, res) => {
  const { email, otp } = req.body
  const record = otpStore[email]

  if (!record) return res.status(400).json({ success: false, message: 'OTP not found' })

  const isExpired = Date.now() > record.expiresAt
  const isMatch = otp === record.otp

  if (isExpired) {
    delete otpStore[email]
    return res.status(400).json({ success: false, message: 'OTP expired' })
  }

  if (!isMatch) {
    return res.status(400).json({ success: false, message: 'Invalid OTP' })
  }

  delete otpStore[email]
  res.status(200).json({ success: true, message: 'OTP verified' })
}
